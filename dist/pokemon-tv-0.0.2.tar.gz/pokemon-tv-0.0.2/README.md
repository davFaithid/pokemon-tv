# Pokemon TV

Watch (currently only the first season) of Pokemon in python3.

# Requirements
Requires:

> [**mpv-1.dll**](https://master.dl.sourceforge.net/project/mpv-player-windows/libmpv/mpv-dev-i686-20180317-git-fbcf2bf.7z) on PATH, 
  configparser,
  python-mpv,
  and python 3.

# TODO:

more episodes

move to json instead of ini config

# Disclaimer

DISCLAIMER: Any and all content presented in this repository is presented for informational and educational purposes only. You (the "user" or "end user") assume any and all responsibility for using this content responsibly. I (davFaithid) claim no responsibiliy or warranty of this product per GNU General Public License revision 3.0 or higher.
